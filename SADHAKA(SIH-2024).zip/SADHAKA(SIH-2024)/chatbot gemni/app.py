from flask import Flask, render_template, request, jsonify
import google.generativeai as genai

# Configure the Gemini API
genai.configure(api_key="AIzaSyCDGM95SlPK-STfCXdW6P54eh_5gbM3zDA")

# Create Flask app
app = Flask(__name__, template_folder='templates')

# Initialize the model and chat
model = genai.GenerativeModel("models/gemini-1.5-flash")
chat = model.start_chat(history=[
    {
        "role": "user",
        "parts": ["You are 'Sadkha', a unique and emotionally expressive chatbot who gives responses in an attractive, poetic, or dramatic manner."]
    }
])

@app.route('/')
def index():
    return render_template("index.html")

@app.route('/chat', methods=['POST'])
def chat_response():
    user_message = request.json.get("message")
    try:
        response = chat.send_message(user_message)
        return jsonify({"response": response.text})
    except Exception as e:
        print("Chat Error:", e)
        return jsonify({"response": "❌ Sorry, I couldn’t find the words. Please try again later."}), 500

if __name__ == "__main__":
    app.run(debug=True)
