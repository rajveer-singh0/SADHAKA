document.getElementById('close-button').addEventListener('click', function() {
    window.close();
});

document.getElementById('bmi-form').addEventListener('submit', function(e) {
    e.preventDefault();

    let height = parseFloat(document.getElementById('height').value);
    let weight = parseFloat(document.getElementById('weight').value);
    let heightUnit = document.getElementById('height-unit').value;
    let weightUnit = document.getElementById('weight-unit').value;

    // Convert height and weight to meters and kilograms
    if (heightUnit === 'ft') {
        height *= 0.3048; // Convert feet to meters
    } else if (heightUnit === 'in') {
        height *= 0.0254; // Convert inches to meters
    } else if (heightUnit === 'cm') {
        height *= 0.01; // Convert cm to meters
    }

    if (weightUnit === 'lb') {
        weight *= 0.453592; // Convert pounds to kilograms
    }

    fetch('/calculate_bmi', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `height=${height}&weight=${weight}`
    })
    .then(response => response.json())
    .then(data => {
        if (data.bmi) {
            document.getElementById('result').innerText = `Your BMI is ${data.bmi}`;
            document.getElementById('description').innerText = getBMIDescription(data.bmi);
        } else {
            document.getElementById('result').innerText = `Error: ${data.error}`;
            document.getElementById('description').innerText = '';
        }
    })
    .catch(error => console.error('Error:', error));
});

function getBMIDescription(bmi) {
    if (bmi < 18.5) {
        return 'This is described as underweight.';
    } else if (bmi >= 18.5 && bmi <= 24.9) {
        return 'This is described as the healthy range.';
    } else if (bmi >= 25 && bmi <= 29.9) {
        return 'This is described as overweight.';
    } else if (bmi >= 30 && bmi <= 39.9) {
        return 'This is described as obesity.';
    } else {
        return 'This is described as severe obesity.';
    }
}
