# import os
# import google.generativeai as genai
# from dotenv import load_dotenv

# # Load environment variables from .env file
# load_dotenv()

# # Configure the Google Gemini AI SDK with your API key
# genai.configure(api_key=os.getenv("GEMINI_API_KEY"))

# # Define the configuration for the model
# generation_config = {
#     "temperature": 0,
#     "top_p": 0.95,
#     "top_k": 64,
#     "max_output_tokens": 8192,
#     "response_mime_type": "text/plain",
# }

# # Define safety settings
# safety_settings = [
#     {
#         "category": "HARM_CATEGORY_HARASSMENT",
#         "threshold": "BLOCK_NONE",
#     },
#     {
#         "category": "HARM_CATEGORY_HATE_SPEECH",
#         "threshold": "BLOCK_MEDIUM_AND_ABOVE",
#     },
#     {
#         "category": "HARM_CATEGORY_SEXUALLY_EXPLICIT",
#         "threshold": "BLOCK_MEDIUM_AND_ABOVE",
#     },
#     {
#         "category": "HARM_CATEGORY_DANGEROUS_CONTENT",
#         "threshold": "BLOCK_MEDIUM_AND_ABOVE",
#     },
# ]

# # Create the model with the provided settings and instructions
# model = genai.GenerativeModel(
#     model_name="gemini-1.5-pro",
#     safety_settings=safety_settings,
#     generation_config=generation_config,
#     system_instruction=(
#         "Introduction: I am SADHAK. Welcome to our wellness platform! "
#         "We are here to guide you through your journey in sports, yoga, meditation, and Ayurveda. "
#         "Whether you have questions about workouts, need meditation tips, want to explore yoga postures, "
#         "or seek advice on Ayurveda practices, I'm here to help!\n"
#         "User Engagement: \n"
#         " - If you ask about sports: 'Tell me about your fitness goals, and I'll suggest exercises or sports routines that suit your needs.'\n"
#         " - If you inquire about yoga: 'Would you like to learn about specific poses, breathing techniques, or yoga sequences tailored to your level?'\n"
#         " - If you want to explore meditation: 'Are you looking for guided meditations, mindfulness techniques, or ways to reduce stress?'\n"
#         " - If you're interested in Ayurveda: 'Would you like tips on diet, daily routines, or remedies based on your dosha (body type)?'\n"
#         "Guidance and Personalization: Based on your preferences and goals, I can provide personalized advice and routines. "
#         "Let's start by telling me what you're most interested in or any specific questions you have.\n"
#         "Closing and Encouragement: Remember, your wellness journey is unique, and I'm here to support you every step of the way. How can I assist you today?"
#     ),
# )

# # Start a new chat session
# chat_session = model.start_chat(history=[])

# print("Bot: Hello, how can I help you?")
# print()

# # Main loop to interact with the user
# while True:
#     try:
#         user_input = input("You: ")
#         print()

#         # Send the user's input to the model and get the response
#         response = chat_session.send_message(user_input)
#         model_response = response.text

#         # Print the response
#         print(f'Bot: {model_response}')
#         print()

#         # Append the conversation history if needed (handled internally)
#         chat_session.history.append({"role": "user", "parts": [user_input]})
#         chat_session.history.append({"role": "model", "parts": [model_response]})
#     except KeyboardInterrupt:
#         print("\nChat session ended.")
#         break



import os
from dotenv import load_dotenv

import google.generativeai as genai

# Load environment variables from .env file
load_dotenv()

# Configure the Google Gemini AI SDK with your API key
genai.configure(api_key=os.getenv("GEMINI_API_KEY"))


# Configure the API key

# genai.configure(api_key="AIzaSyCDGM95SlPK-STfCXdW6P54eh_5gbM3zDA")  # Replace with your key

# Initialize the Gemini model (use an available one like gemini-1.5-flash)
model = genai.GenerativeModel("models/gemini-1.5-flash")

# Start a chat with initial instruction to define personality
chat = model.start_chat(history=[
    {
        "role": "user",
        "parts": ["You are 'Sadkha', a unique and emotionally expressive chatbot who gives responses in an attractive, poetic, or dramatic manner."]
    }
])

print("🤖 Sadkha: Hello, dear soul. Ask me anything, and I shall whisper answers with charm and grace.\n(Type 'exit' to stop)\n")

while True:
    user_input = input("You: ")
    if user_input.strip().lower() in ["exit", "quit"]:
        print("🤖 Sadkha: Farewell, kind soul. May your path be bathed in stardust. 🌌")
        break

    try:
        response = chat.send_message(user_input)
        print("\n🤖 Sadkha:", response.text, "\n")
    except Exception as e:
        print("❌ Error:", e)
        break
