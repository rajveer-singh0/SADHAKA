// document.addEventListener('DOMContentLoaded', () => {
//     const progressBar = document.querySelector('.progress-bar-fill');
//     const progressPercentage = document.querySelector('.progress-percentage');

//     // Simulate loading progress
//     let progress = 0;
//     const interval = setInterval(() => {
//         progress += 5;
//         progressBar.style.width = `${progress}%`;
//         progressPercentage.textContent = `${progress}%`;

//         if (progress >= 80) {
//             clearInterval(interval);
//             document.querySelector('.loading-overlay').style.display = 'none';
//         }
//     }, 100);
// });



// after adding 
document.addEventListener('DOMContentLoaded', () => {
    const progressBar = document.querySelector('.progress-bar-fill');
    const progressPercentage = document.querySelector('.progress-percentage');

    // Simulate loading progress
    let progress = 0;
    const interval = setInterval(() => {
        progress += 5;
        progressBar.style.width = `${progress}%`;
        progressPercentage.textContent = `${progress}%`;

        if (progress >= 80) {
            clearInterval(interval);
            document.querySelector('.loading-overlay').style.display = 'none';
        }
    }, 100);
});

// Function to close the window
function closeWindow() {
    window.close();
}
