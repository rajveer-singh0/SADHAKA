from flask import Flask, render_template, request, jsonify

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/calculate_bmi', methods=['POST'])
def calculate_bmi():
    try:
        height = float(request.form['height'])
        weight = float(request.form['weight'])
        bmi = weight / ((height) ** 2)
        return jsonify({'bmi': round(bmi, 2)})
    except ValueError:
        return jsonify({'error': 'Invalid input'}), 400

if __name__ == "__main__":
    app.run(debug=True, port=4000)
