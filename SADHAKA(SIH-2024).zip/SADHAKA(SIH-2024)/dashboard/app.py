# from flask import Flask, render_template

# app = Flask(__name__)

# @app.route('/')
# def index():
#     return render_template('index.html')

# @app.route('/dashboard')
# def dashboard():
#     user_data = {
#         'honor_score': 85,
#         'progress': 70,
#         'next_task': 'Complete a 30-minute yoga session'
#     }
#     return render_template('dashboard.html', user_data=user_data)

# if __name__ == '__main__':
#     app.run(debug=True)



from flask import Flask, render_template

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/dashboard')
def dashboard():
    user_data = {
        'honor_score': 85,
        'progress': 70,
        'next_task': 'Complete a 30-minute yoga session'
    }
    return render_template('dashboard.html', user_data=user_data)

if __name__ == '__main__':
    # Run the app on port 8000 or 3000
    app.run(debug=True, port=8000)  # Change port=8000 to port=3000 if needed
